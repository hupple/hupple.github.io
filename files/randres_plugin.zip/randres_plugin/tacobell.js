// content.js
// alert("Hello from your Chrome extension!");

// Highlight text
var answers = [
    ["Have you ever worked for this company before", "No"],
    ["How many years experience do you have", "At least 1 to 3"],
    ["How many employers have you worked for in the past two years?", "Two"],
    ["Have you ever been terminated from a job or asked to resign", "No"],
    ["Are you able to speak and read English", "Yes"],
    ["Are you able to perform the essential duties of the position", "Yes"],
    ["Are you able to lift up to 50 lbs and stand on your feet", "Yes"],
    ["How would you define your teamwork abilities", "You are a team player"],
    ["Can you perform well in a fast-paced service", "All the time"],
    ["Are you willing to wear a uniform and follow grooming", "Yes"],
    ["What are your thoughts on working beyond your normal scheduled", "Whatever it takes"],
    ["Are you willing to work a flexible work schedule including nights", "Yes"],
    ["When solving a problem, which best describes you", "Try to solve"],
    ["Rate your knowledge with handling customer complaints", "Exceptional"],
    ["When dealing with difficult guests, you should", "Politely reassure the guest"],
    ["I am willing to do tasks outside of my job description", "Yes"],
    ["What is your experience level operating an electronic or computerized cash", "Experienced"],
    ["What is your experience level handling cash and providing change", "Experienced"],
    ["Do you enjoy working with and serving the public", "All the time"],
    ["If you saw a co-worker stealing a small item or giving food to a friend", "Privately talk to"],
    ["Are you currently in school?", "No"],
    ["Are you ServSafe Certified", "Yes"],
    ["Would you be willing to consent to a background check or reasonable suspicion drug testing", "Yes"],
    ["Are you 16 years of age or older?", "Yes"],
    ["Are you at least 17 years of age or older", "Yes"],
    ["Would you be willing to consent to background check", "Yes"]
];
var spans = document.getElementsByTagName("div");

for (var i = 0; i < answers.length; i++) { 
    for (var j = 0; j < spans.length; j++) { 

        var firstText = "";
        for (var k = 0; k < spans[j].childNodes.length; k++) {
            var curNode = spans[j].childNodes[k];
            if (curNode.nodeName === "#text") {
                firstText = curNode.nodeValue;
                break;
            }
        }

        if (firstText.includes(answers[i][0]) && firstText.length > 0) {
            var founds = spans[j].parentElement.parentElement.parentElement.parentElement.parentElement.getElementsByTagName("span");

            for (var l = 0; l < founds.length; l++) {
                var secondText = "";
                for (var m = 0; m < founds[l].childNodes.length; m++) {
                    var curNode = founds[l].childNodes[m];
                    if (curNode.nodeName === "#text") {
                        secondText = curNode.nodeValue;
                        break;
                    }
                }
            
                if (secondText.includes(answers[i][1])) {
                    // find the correct thing to higlight
                    founds[l].style.backgroundColor = "#FDFF47";
                    break;
                }
            }
        }
    }
}

/// Assessment part
var answers = [
    ["I am never in a bad mood", "Disagree"],
    ["I feel satisfied at the end of the day when", "Agree"],
    ["I am almost always optimistic", "Agree"],
    ["I am never late for work", "Agree"],
    ["I tend to delay (or put off) things that need to be done", "Strongly Agree"],
    ["I am well-liked by everyone I know", "Agree"],
    ["I always see a task through to the end", "Agree"],
    ["Doing more than is expected of me is usually a waste of time", "Disagree"],
    ["Criticism never bothers me", "Disagree"],
    ["At work (or school), many people are up to no", "Disagree"],
    ["Throughout life, I have always made good", "Disagree"],
    ["I sometimes wish that people would slow down a little and give me a chance to catch up", "Agree"],
    ["I like to do more than is expected of me", "Agree"],
    ["I like every detail of my work to be perfect", "Agree"],
    ["It is natural for people to forget to do things, especially if the tasks are not interesting", "Agree"],
    ["A lot of companies have unnecessary rules just because they want to control people", "Disagree"],
    ["Other people do not work as hard as I do", "Agree"],
    ["I am somewhat careless about checking details", "Disagree"],
    ["When things don't go as planned, it bothers me", "Agree"],
    ["I like to be with people all of the time", "Agree"],
    ["At work, I always try to see the best in any situation", "Disagree"],
    ["For this question please mark \"Strongly Agree\"", "Strongly Agree"],
    ["I am often full of energy", "Agree"],
    ["I can do a large amount of work in a short time", "Agree"],
    ["I do my best work under pressure", "Disagree"],
    ["I never misplace things", "Disagree"],
    ["In the past, I have had difficulty getting along with supervisors", "Disagree"],
    ["I prefer when things are not busy at work and there is less to do", "Agree"],
    ["After a strenuous work day, I find it hard to motivate myself to go back to work", "Agree"],
    ["People think I am a very energetic person", "Agree"],
    ["When things go wrong, I try to find someone else to blame", "Disagree"],
    ["I never let my emotions get in the way when making important decisions", "Agree"],
    ["I never make decisions that I later feel bad about", "Disagree"],
    ["I never feel jealous of other people", "Disagree"],
    ["Stress and pressure almost never affect me at work", "Disagree"],
    ["I never repeat rumors about other people", "Agree"],
    ["In the long run, people who give their best effort at work are taken advantage of by the company", "Disagree"],
    ["I work harder than most people", "Agree"],
    ["I have always been a hard worker", "Agree"],
    ["I do not know how some people get so much done", "Disagree"],
    ["Sometimes I spread work out to fill the time rather than find more things to do", "Disagree"],
    ["I wish I had more energy", "Disagree"],
    ["I believe most people who are successful at work bent the rules a little to get where they are", "Disagree"],
    ["I have often found it necessary to stand up for what I believe to be right", "Agree"],
    ["A major reason for my success is, or will be, that I get all the details correct", "Agree"],
    ["I enjoy making other people do what I want them to do", "Disagree"],
    ["People think of me as being a very social person", "Agree"],
    ["I work more slowly and methodically than most people", "Disagree"],
    ["I resent having friends or members of my family tell me what to do", "Disagree"],
    ["I would rather work alone", "Disagree"],
    ["When I make a mistake, I cannot stop thinking about it", "Agree"],
    ["I would like to have enough money or power in order to impress people who think they are", "Disagree"],
    ["I am a listener rather than a talker in social conversations", "Disagree"],
    ["There are some people whose actions seem continually to irritate me", "Agree"],
    ["I am so naturally friendly that people immediately feel comfortable with me", "Agree"],
    ["I have received compliments from others on my ability to plan and organize work", "Agree"],
    ["I enjoy getting to know new people", "Strongly Agree"],
    ["When I resent the actions of anyone, I promptly tell them so", "Agree"],
    ["I tend to limit the people I know to a select few", "Disagree"],
    ["I have difficulty making new friends", "Disagree"],
    ["I like to take part in many social activities", "Agree"],
    ["In most cases, it is important to get what I want even if I have to hurt someone to get it", "Disagree"],
    ["I hate to lose in a contest", "Agree"],
    ["I like to spend time organizing and planning my work", "Agree"],
    ["It bothers me to have other people tell me what I should do", "Disagree"],
    ["In group activities, I almost always feel that my own plans are best", "Agree"],
    ["The opinions of most people are worthless", "Disagree"],
    ["I am so shy it bothers me", "Disagree"],
    ["I find it easy to start a conversation with strangers", "Agree"],
    ["To be successful, it is important to be organized", "Agree"],
    ["I have frequently wanted to tell people who ask a lot of personal questions to leave me alone", "Disagree"],
    ["I am unhappy unless things in an organization go pretty much as I want them to", "Disagree"],
    ["After being introduced to someone, I often cannot think of things to say to make good conversation", "Disagree"],
    ["I find it easy to make new friends", "Agree"],
    ["I usually remain cheerful in spite of trouble at work", "Agree"],
    ["I hate to lose an argument even when the issue is not very important", "Disagree"],
    ["When someone is not playing fair, I like to see them lose", "Agree"],
    ["A sudden shift in work (or school) priorities creates stress for me", "Disagree"],
    ["Realistically, I will change jobs ___ times in the next year", "Zero"],
    ["In the past, I have sometimes chosen to skip out on work", "Disagree"],
    ["Most supervisors accept that I cannot always be on time for work, because things just come up", "Disagree"],
    ["Even when I am feeling well, I have had difficulty getting to work", "Disagree"],
    ["Your friends say you are too nice", "Agree"],
    ["To avoid problems at work, you believe you have to adjust the truth a little", "Disagree"],
    ["You sometimes feel bored and tired for no reason", "Disagree"],
    ["Keeping things neat and organized is not worth the time it takes", "Disagree"],
    ["You believe most people who are successful at work bent the rules", "Disagree"],
    ["At work, you like for things to be organized and", "Agree"],
    ["People see you as being a very nice", "Agree"],
    ["You usually prefer to let others take the lead", "Disagree"],
    ["You dislike being hurried in your work", "Disagree"],
    ["You are sometimes too sensitive to people", "Disagree"],
    ["You have days in which it seems that everything goes", "Disagree"],
    ["You hate to lose an argument even when the issue is not very", "Disagree"],
    ["You enjoy working on a number of task", "Agree"],
    ["You like to have plenty of time to stop", "Disagree"],
    ["There are fifty hours in a day.", "Disagree"],
    ["You like to do more than is expected of you", "Agree"],
    ["The people you work with use politeness", "Disagree"],
    ["You can count to ten.", "Agree"],
    ["You like to be the leader of the group.", "Agree"],
    ["Most of the time you are very active", "Agree"],
    ["You keep your opinions to yourself until you are asked", "Disagree"],
    ["Because you have so many problems of your own", "Disagree"],
    ["You are more effective when you do not have too many things", "Disagree"],
    ["Having a well-ordered day is not very important", "Disagree"],
    ["You are often discouraged.", "Disagree"],
    ["People have criticized you unfairly to others.", "Disagree"],
    ["You sometimes wish that people would slow down a little and give you a chance to catch up.", "Disagree"],
    ["You handle criticism better than most people", "Agree"],
    ["You can read well enough to complete this survey", "Agree"],
    ["Generally, people feel that being nice to other people", "Disagree"],
    ["Most people waste too much time on the details", "Disagree"],
    ["People focus too much on your weaknesses and ignore your strengths", "Disagree"],
    ["You resent having friends or members of your family te", "Disagree"],
    ["You follow a systematic approach for do", "Agree"],
    ["You are confident that the future will be good", "Agree"],
    ["You are too sensitive about what others think about", "Disagree"],
    ["Making someone else smile can be very rewarding", "Agree"],
    ["You often do not receive the credit you deserve", "Disagree"],
    ["You work harder than most people", "Agree"],
    ["Jumping around between tasks keeps me from getting bored", "Agree"],
    ["You have received compliments from others on your ability to plan and organize work.", "Agree"],
    ["Your mood often changes from happiness to sadness without you knowing why.", "Disagree"],
    ["You wish people at work would be more honest than they usually are", "Agree"],
    ["You feel that so far, you have made the right decisions in life", "Agree"],
    ["Most people are successful in their work because they know the right people", "Disagree"],
    ["There are seven days in a week", "Agree"],
    ["At work, you find it difficult to discuss differences of opinion without getting into an argument", "Disagree"],
    ["You like every detail of your work to be perfect", "Agree"],
    ["Most people find you a bit uncaring or unfeeling", "Disagree"],
    ["You get a sense of accomplishment from doing several things at once", "Agree"],
    ["When a person acts unfairly you hesitate to say anything", "Disagree"],
    ["You put other people's needs ahead of your own", "Agree"],
    ["Other people find it hard to work as fast as you", "Agree"],
    ["Most people will tell some lies to be successful in the", "Disagree"],
    ["You sometimes find it overwhelming to manage many demands", "Disagree"],
    ["You often help others settle their disputes", "Agree"],
    ["You would rather have a job where you can focus on something rather than having many different things to do", "Disagree"],
    ["Being kind is more important than getting", "Agree"],
    ["There are eighty days in a month", "Disagree"],
    ["In a group, you are often the one who takes the lead", "Agree"],
    ["A sudden shift in work priorities creates stress for you.", "Disagree"],
    ["Sometimes you get satisfaction out of disobeying the rules.", "Disagree"],
    ["At work, you are quicker to take charge of a situation than most people you know.", "Agree"],
    ["You would avoid most accidents if you always followed the rules.", "Agree"],
    ["In a group, you are often the one who takes the lead", "Agree"],
    ["Somehow, you have had more than your share of accidents and injuries.","Disagree"],
    ["It irritates you when there are frequent changes in what you are asked to do.","Disagree"],
    ["If you put more into a job than they are willing to pay you, you are cheating yourself.","Disagree"],
    ["Rather than ask someone else, you tend to solve problems yourself.","Agree"],
    ["Safety is more the responsibility of the manager than the employee.","Disagree"],
    ["You dislike receiving new instructions in the middle of a task.","Disagree"],
    ["Getting hurt at work is often the result of a lack of attention.","Agree"],
    ["Most safety rules are more trouble than they are worth.","Disagree"],
    ["You always see a task through to the end.","Agree"],
    ["You often resist doing what you are told to do.","Disagree"],
    ["You are constantly aware of potential safety hazards at work.","Agree"],
    ["At work, far too many people try to take as much as they can and give back as little as possible.","Disagree"],
    ["When a problem comes up, it is usually easier to solve it yourself.","Agree"],
    ["You prefer to finish a task before starting the next one.",'Agree'],
    ["A major reason for your success is, or will be, that you get all the details correct.",'Agree'],
    ["All accidents at home and at the workplace are preventable.",'Agree'],
    ["You wish you had more energy.","Disagree"],
    ["You have so much energy you find it hard to relax.","Disagree"],
    ["You are somewhat careless about checking details.","Disagree"],
    ["Others come to you before your manager when they have questions or need advice.","Agree"],
    ["You like to spend time organizing and planning your work.","Agree"],
    ["You know that you will succeed at almost anything you try to do.","Agree"],
    ["You tend to delay (or put off) things that need to be done.","Disagree"],
    ["Doing more than is expected of you is usually a waste of time.","Disagree"],
    ["You dislike frequent changes in your schedule.","Disagree"],
    ["Compared to others, you tend to take charge and give direction.","Agree"],
    ["You are quick to adapt to changes, even if you disagree with them.","Agree"],
    ["Your actions on the job have little effect on the safety of others.","Disagree"],
    ["In most work situations, people take more than they give.","Disagree"],
    ["Stress and pressure almost never affect you.","Agree"],
];
var spans = document.getElementsByTagName("span");

for (var i = 0; i < answers.length; i++) { 
    for (var j = 0; j < spans.length; j++) { 

        var firstText = "";
        for (var k = 0; k < spans[j].childNodes.length; k++) {
            var curNode = spans[j].childNodes[k];
            if (curNode.nodeName === "#text") {
                firstText = curNode.nodeValue;
                break;
            }
        }

        if (firstText.includes(answers[i][0]) && firstText.length > 0) {
            var founds = spans[j].parentElement.parentElement.getElementsByTagName("span");

            for (var l = 0; l < founds.length; l++) {
                var secondText = "";
                for (var m = 0; m < founds[l].childNodes.length; m++) {
                    var curNode = founds[l].childNodes[m];
                    if (curNode.nodeName === "#text") {
                        secondText = curNode.nodeValue;
                        break;
                    }
                }
            
                if (secondText.includes(answers[i][1])) {
                    // find the correct thing to higlight
                    founds[l].style.backgroundColor = "#FDFF47";
                    break;
                }
            }
        }
    }
}

